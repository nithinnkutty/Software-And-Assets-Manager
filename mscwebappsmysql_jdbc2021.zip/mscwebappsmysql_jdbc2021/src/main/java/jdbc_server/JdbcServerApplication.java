package jdbc_server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//leave the main function there, it is okay
@SpringBootApplication
public class JdbcServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(JdbcServerApplication.class, args);
    }

}
