package jdbc_server.repository;

import jdbc_server.form.AddEmployeeForm;


public interface EmployeeRepository {
    public Object findEmployeeByName(String surname);
    public Object findAllEmployee();
    boolean addEmployee(AddEmployeeForm addEmployeeForm);

    boolean SampleFunction(AddEmployeeForm addEmployeeForm);



}
