package jdbc_server.repository;

import jdbc_server.DTO.EmployeeDTO;
import jdbc_server.form.AddEmployeeForm;
import jdbc_server.model.EmployeeMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;



import java.util.List;

@Repository
public class EmployeeRepositoryJDBC implements EmployeeRepository {

//https://docs.spring.io/spring-framework/docs/current/javadoc-api/org/springframework/jdbc/core/JdbcTemplate.html
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public EmployeeRepositoryJDBC(JdbcTemplate aTemplate) {
        jdbcTemplate = aTemplate;
    }

    //in this class ,write the sql statements
    @Override
    public EmployeeDTO findEmployeeByName(String surname) {
        EmployeeDTO employeeDTO = (EmployeeDTO) jdbcTemplate.queryForObject(
                // queryForObject(String sql, Object[] args, RowMapper<T> rowMapper)
                "select ID,Name,Department,Authority from employee where name=?" ,
                new Object[]{surname}, new EmployeeMapper());
        return employeeDTO;

    }

    @Override
    public List<EmployeeDTO> findAllEmployee() {
        return jdbcTemplate.query(
                "select ID,Name,Department,Authority from Employee" ,
                 new EmployeeMapper());
    }

    @Override
    public boolean addEmployee(AddEmployeeForm addEmployeeForm) {
        int rows = jdbcTemplate.update(
                "insert into Employee (Name,Department,Authority) values(?,?,?)" ,
                new Object[]{addEmployeeForm.getName(),addEmployeeForm.getDepartment(),addEmployeeForm.getAuthority()});
        return rows>0;
    }

    public boolean SampleFunction(AddEmployeeForm addEmployeeForm) {
        int rows = jdbcTemplate.update(
                "insert into Employee (Name,Department,Authority) values(?,?,?)" ,
                new Object[]{addEmployeeForm.getName(),addEmployeeForm.getDepartment(),addEmployeeForm.getAuthority()});
        return rows>0;
    }


}