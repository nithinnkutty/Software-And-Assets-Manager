package uk.ac.cf.cs.nsa.web.jdbcserver.jdbc_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
